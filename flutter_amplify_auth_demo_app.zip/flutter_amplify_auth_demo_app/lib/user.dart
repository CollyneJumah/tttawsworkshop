class User {
  final String name;

  User(this.name);
}
