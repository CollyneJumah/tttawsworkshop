package com.example.flutter_amplify_auth_demo_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
